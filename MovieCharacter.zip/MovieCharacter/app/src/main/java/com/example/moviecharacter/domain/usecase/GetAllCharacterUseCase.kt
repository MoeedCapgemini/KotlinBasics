package com.example.moviecharacter.domain.usecase

import com.example.moviecharacter.domain.repository.CharacterRepository
import javax.inject.Inject

class GetAllCharacterUseCase @Inject constructor(private val repository: CharacterRepository) {
    operator fun invoke() = repository.getAllCharacters()
}