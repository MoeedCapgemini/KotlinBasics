package com.example.moviecharacter.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FakeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(fakeEntity: FakeEntity)

    @Query("SELECT * FROM fake_table")
    suspend fun getAllFakeEntities():List<FakeEntity>

}