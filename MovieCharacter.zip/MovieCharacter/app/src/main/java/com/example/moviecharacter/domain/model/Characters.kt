package com.example.moviecharacter.domain.model

data class Characters(
    val actor: String,
    val id: String,
    val image: String,
    val name: String,

)