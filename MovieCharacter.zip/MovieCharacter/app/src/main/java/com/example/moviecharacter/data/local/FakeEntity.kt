package com.example.moviecharacter.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "fake_table")
data class FakeEntity(
    @PrimaryKey(autoGenerate = true)
    val id:Int=0,
    val name:String,
    val des:Int,
    val createdDate:Date
)
