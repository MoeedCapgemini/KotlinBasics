package com.example.moviecharacter.core.utils

object Constants {
    const val BASE_URL = "https://hp-api.onrender.com/api/"
}