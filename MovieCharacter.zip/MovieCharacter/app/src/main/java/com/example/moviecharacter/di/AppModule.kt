package com.example.moviecharacter.di

import com.example.moviecharacter.core.utils.Constants.BASE_URL
import com.example.moviecharacter.data.api.CharactersApi
import com.example.moviecharacter.data.repository.CharacterRepositoryImpl
import com.example.moviecharacter.domain.repository.CharacterRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
object AppModule {

    @Provides
    @Singleton
    fun providesRetrofitInstance():Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()


    @Provides
    @Singleton
    fun providesCharactersApi(retrofit: Retrofit):CharactersApi = retrofit.create(CharactersApi::class.java)

    @Provides
    @Singleton
    fun providesCharacterRepository(api: CharactersApi):CharacterRepository{
        return CharacterRepositoryImpl(api)

    }




}