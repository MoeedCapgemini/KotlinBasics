package com.example.moviecharacter.data.dto

data class WandDto(
    val core: String,
    val length: Double,
    val wood: String
)