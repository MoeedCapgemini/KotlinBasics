package com.example.moviecharacter.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE

    )]
)
data class Post(
    @PrimaryKey(autoGenerate = true)
    val postId: Int = 0,
    val content: String,
    val userId: Int
)
