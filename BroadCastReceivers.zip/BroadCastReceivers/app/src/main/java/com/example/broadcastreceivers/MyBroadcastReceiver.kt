package com.example.broadcastreceivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MyBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if ("com.example.MY_CUSTOM_ACTION".equals(intent?.action)) {
            Toast.makeText(context, "BroadCAst received", Toast.LENGTH_SHORT).show()
        }
    }
}