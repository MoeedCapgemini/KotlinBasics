package com.example.broadcastreceivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast

class MyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_AIRPLANE_MODE_CHANGED -> {
                Toast.makeText(context, "Airplane mode changed", Toast.LENGTH_SHORT).show()
            }

            Intent.ACTION_POWER_CONNECTED -> {
                Toast.makeText(context, "Power connected", Toast.LENGTH_SHORT).show()
            }

            Intent.ACTION_POWER_DISCONNECTED -> {
                Toast.makeText(context, "Power disconnected", Toast.LENGTH_SHORT).show()
            }
        }
        /*val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d("MyReceiver", "Device booted")
        }*/
    }
}