package com.example.broadcastreceivers

import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.broadcastreceivers.ui.theme.BroadCastReceiversTheme

class MainActivity : ComponentActivity() {
    private lateinit var receiver : MyReceiver
    private lateinit var networkChangeReceiver: NetworkChangeReceiver
    private var myBroadcastReceiver = MyBroadcastReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            val intentFilter3 = IntentFilter("com.example.MY_CUSTOM_ACTION")
            registerReceiver(myBroadcastReceiver,intentFilter3)



            receiver = MyReceiver()
            networkChangeReceiver = NetworkChangeReceiver()

            val filter1 = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
            registerReceiver(networkChangeReceiver,filter1)


            //custom
            val intent = Intent("come.example.MY_CUSTOM_ACTION")
            sendBroadcast(intent)



            val filter = IntentFilter(Intent.ACTION_BOOT_COMPLETED)
            registerReceiver(receiver, filter)


            val filter2 = IntentFilter().apply {
                addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }

            registerReceiver(receiver,filter2)

        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }
}

