package com.example.content_provider

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.content_provider.ui.theme.BroadCastReceiversTheme

class RestoreActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

            if (savedInstanceState != null) {
                val restoredText = savedInstanceState.getString("user_input")
            }


        }
    }


    /*
    ✅ So, which one is called?
onCreate() is always called when the activity is recreated.
onRestoreInstanceState() is called only if there is saved state (i.e., onSaveInstanceState() was previously called).



    * */

    /*
    1. Save the state
Override onSaveInstanceState() to store data in a Bundle.
*/
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("user_input", "ABC")
    }


    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val restoredValue = savedInstanceState.getString("user_input")

    }
}




