package com.example.sslpinning.encypted_shared_pref

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object EncryptedSharedPreferencesClass {
//    Initialize EncryptedSharedPreferences
//    Ideal for storing sensitive data like tokens, credentials, etc.
//    Safely store small pieces of sensitive data like tokens or user settings.
//    SharedPreferences / EncryptedSharedPreferences:
//    Persisted across reboots.
//    Safe for storing small, secure data like tokens or flags.
//    Room Database / File Storage:
//    Persisted unless manually deleted or app is uninstalled.
//    Good for structured or large data.

//🔐 Benefits of EncryptedSharedPreferences
//Automatic Encryption
//
//Data is encrypted before being saved and decrypted when read.
//Uses strong encryption algorithms like AES-256.
//Secure Key Management
//
//Keys are stored in the Android Keystore, which is hardware-backed on most devices.
//You don’t need to manage or store encryption keys manually.
//Easy to Use
//
//Works just like regular SharedPreferences, so you don’t need to learn a new API.
//Example:
//
//Protects Against Data Theft
//
//Even if someone gains root access or steals the device, the data remains encrypted and unreadable without the key.
//Persistence Across Reboots
//
//Data remains safe and accessible even after the device restarts.
//No Need for Manual Encryption
//
//Saves development time and reduces the risk of implementing encryption incorrectly.
//✅ Best Use Cases
//Storing authentication tokens
//Saving user preferences that are sensitive
//Keeping session data or flags securely

    fun getEncryptedPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    }
}