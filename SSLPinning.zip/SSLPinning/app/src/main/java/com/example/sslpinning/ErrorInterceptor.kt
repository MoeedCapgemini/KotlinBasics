package com.example.sslpinning

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

class ErrorInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request: Request = chain.request()
        val response = chain.proceed(request)
        when (response.code) {
            400 -> {
                //show bad request error message
            }

            401 -> {
                //show unauthorized error message
            }

            403 -> {
                //show forbidden message
            }

            404 -> {
                //show not found message
            }

        }
        return response

    }
}