package com.example.sslpinning

import androidx.core.os.BuildCompat
import okhttp3.Cache
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File

class RetrofitClient {

    //Logging Interceptor

    private val loggingInterceptor = HttpLoggingInterceptor().apply {

        level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BODY
             } else {
             HttpLoggingInterceptor.Level.NONE
             }

    }



    //SSL Pinning
    fun getPinnedHttpClient(): OkHttpClient {
        val certificatePinner = CertificatePinner.Builder()
            .add("", "")
            .build()
        return OkHttpClient.Builder()
            .certificatePinner(certificatePinner)
            .build()
    }


    fun myCacheInterceptorClient():OkHttpClient{
        return OkHttpClient().newBuilder()
            .cache(Cache(File(applicationContext.cacheDir, "http-cache"), 10L * 1024L * 1024L)) // 10 MiB
            .addNetworkInterceptor(CacheInterceptor())
            .addInterceptor(ForceCacheInterceptor())
            .build()
    }

    fun myAuthTokenClient():OkHttpClient{
        return OkHttpClient().newBuilder()
            .addInterceptor(AuthTokenInterceptor())
            .build()
    }

    fun myHttpInterceptorClient(): OkHttpClient {
        return OkHttpClient().newBuilder()
            .addInterceptor(ErrorInterceptor())
            .build()
    }

    fun createRetrofit(): Retrofit {
        val okHttpClient = getPinnedHttpClient()
        return Retrofit.Builder()
            .baseUrl("")
            .client(okHttpClient)
            .client(myHttpInterceptorClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    }


    val retrofit = createRetrofit()
    val api = retrofit.create(TestApi::class.java)


}
