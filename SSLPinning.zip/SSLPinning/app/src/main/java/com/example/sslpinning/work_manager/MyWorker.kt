package com.example.sslpinning.work_manager

import android.content.Context
import android.util.Log
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import okio.IOException

class MyWorker(appContext: Context, workerParameters: WorkerParameters) :
    Worker(appContext, workerParameters) {
    override fun doWork(): Result {
        return try {
            Log.d("MyWorker", "Background task is running")
            return Result.success()

        }catch (e:IOException){
            val output = workDataOf("error" to "Netwrok Time out")
            Result.retry()

        }catch (e:Exception){
            val outDataOf = workDataOf("Failure" to "Failedd")
            Result.failure()

        }


    }

}


