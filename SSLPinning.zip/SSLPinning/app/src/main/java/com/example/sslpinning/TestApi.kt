package com.example.sslpinning

interface TestApi {
}