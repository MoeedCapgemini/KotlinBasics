package com.example.sslpinning.work_manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.unit.Constraints
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class WorkManagerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {


            val workRequest = PeriodicWorkRequestBuilder<MyWorker>(15,TimeUnit.MINUTES).build()

            WorkManager.getInstance(baseContext)
                .getWorkInfoByIdLiveData(workRequest.id)
                .observe(this){workInfo->
                    if (workInfo != null && workInfo.state== WorkInfo.State.FAILED) {
                        val error = workInfo.outputData.getString("Failure")

                    }

                }


            /*WorkManager.getInstance(baseContext).enqueueUniquePeriodicWork(
                "abd",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest

            )*/
        }
    }
}

