package org.example

class Singleton private constructor(){
    var counter=0

    fun incrementCounter(){
        counter++
    }

    companion object{
        @Volatile
        private var INSTANCE:Singleton?=null

        fun getInstance():Singleton{
            return INSTANCE?: synchronized(this){
                INSTANCE?:Singleton().also { INSTANCE=it }
            }
        }
    }
}

fun main() {
    val singleton = Singleton.getInstance()
    singleton.incrementCounter()
    println(singleton.counter)

    val singleton2 = Singleton.getInstance()
    singleton2.incrementCounter()
    println(singleton2.counter)

    println(singleton == singleton2)
}