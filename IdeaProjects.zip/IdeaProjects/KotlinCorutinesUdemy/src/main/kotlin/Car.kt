package org.example

class Car {
    companion object {
        fun getDrivingInstructions(): String {
            return "Safe Driving"
        }
    }
}

fun main() {
    val list:List<String> = List(100){"$it"}
    Car.getDrivingInstructions()
}