package org.example

//5. Factory Pattern
//The Factory Pattern is used to create objects without specifying the exact class of object that will be created.
// This can help in managing object creation logic and making it more modular.
//
//Key Advantages:
//
//Centralizes the object creation logic.
//Can provide different implementations of an interface.

//1. Model-View-ViewModel (MVVM)
//2. Singleton Pattern
//3. Repository Pattern
//4. Observer Pattern
//5. Factory Pattern
//6. Dependency Injection (DI)
//7. Adapter Pattern
//8. Command Pattern


interface Animal {
    fun makeSound()
}

class Dog : Animal {
    override fun makeSound() {
        println("Woo")
    }
}

class Cat : Animal {
    override fun makeSound() {
        println("meow")
    }
}

object AnimalFactory {
    fun getAnimal(type: String): Animal {
        return when (type) {
            "Dog" -> Dog()
            "Cat" -> Cat()
            else -> throw IllegalArgumentException("Unknown Animal type")
        }
    }
}