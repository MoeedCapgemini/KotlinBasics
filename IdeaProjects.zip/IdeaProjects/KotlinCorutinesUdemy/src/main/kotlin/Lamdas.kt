package org.example

fun main() {
    val nums: List<Int> = listOf(1, 2, 3, 4, 5, 6)

    nums.forEach { println(it) }

    val list:List<Int> = nums.map { it*it }

    val userList:List<User> = listOf(
        User(1,"A"),
        User(2,"B"),
        User(3,"C")

    )

    val paidUserList:List<PaidUser> = userList.map {
        PaidUser(it.id,it.name,"hdhd")
    }



    /*val list1:List<Int> = nums.filter { it % 2 !=0 }
    println(list1)

    val userList:List<User> = listOf(
        User(1,"A"),
        User(2,"B"),
        User(3,"C")

    )

    userList.filter { it.id == 2 }*/

}

data class User(val id:Int,val name:String)
data class PaidUser(val id:Int,val name:String,val type:String)


