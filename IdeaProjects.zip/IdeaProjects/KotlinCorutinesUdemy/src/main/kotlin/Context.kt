package org.example

import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {   }
}