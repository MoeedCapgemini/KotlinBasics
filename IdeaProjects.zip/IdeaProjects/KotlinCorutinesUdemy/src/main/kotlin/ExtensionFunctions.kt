package org.example


fun String.slim(): String {
    return this.substring(1, length - 1)
}

fun String.lastCharr(): Char = this[this.length - 1]

fun String.lastChar(): Char {
    return this[this.length - 1]
}

fun String.countVowels(): Int {
    var count = 0
    for (char in this)
        if (char in "aeiouAEIOU") count++
    return count

}

fun MutableList<Int>.swap(index1: Int, index2: Int) {
    val temp = this[index1]
    this[index1] = this[index2]
    this[index2] = temp
}

fun calculate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}

fun main() {
    val numbers = listOf(1, 2, 3, 4, 5)
    val evenNumbers = numbers.filter { it % 2 == 0 }

//    val sum = calculate(5, 4) { x, y -> x + y }
//    println(sum)

//    val name = "Moeed"
//    println(name.slim())
}
