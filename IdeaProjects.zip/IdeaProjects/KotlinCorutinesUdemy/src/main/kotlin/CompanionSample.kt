package org.example

fun main() {


    //val companionSample = CompanionSample()
    println(CompanionSample.getData())
    println(CompanionSample.object1.getData2())


}

class CompanionSample {
    private var companionSample: CompanionSample?=null
    private lateinit var companionSample1: CompanionSample

    companion object {
        @JvmStatic
        fun getData() = "Some Data"
    }

    object object1 {
        fun getData2() = "Some Data2"
    }
}

