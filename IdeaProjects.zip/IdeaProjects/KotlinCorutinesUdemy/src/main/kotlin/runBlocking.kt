package org.example

import kotlinx.coroutines.*

fun main() = runBlocking{
    val supervisorJob = SupervisorJob()
    val scope = CoroutineScope(Dispatchers.Default + supervisorJob)
    scope.launch {
        try {
            delay(500L)
            throw Exception("Error in first task")

        }catch (e:Exception){
            println("Caught exception in task1: ${e.message}")
        }
    }

    scope.launch {
        delay(1000)
        println("Second task is running")
    }
    delay(2000)


}
