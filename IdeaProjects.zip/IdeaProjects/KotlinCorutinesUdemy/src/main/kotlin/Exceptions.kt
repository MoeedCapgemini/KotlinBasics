package org.example

import kotlinx.coroutines.*
import java.security.spec.ECField

fun main() {
    runBlocking {
        val myHandler = CoroutineExceptionHandler{coroutineContext, throwable ->
            println("Exceptions Handled ${throwable.localizedMessage}")
        }
        val job = GlobalScope.launch(myHandler) {
            println("Throwing exception from job")
            throw IndexOutOfBoundsException("Exception in coroutine")
        }
        job.join()

        val deferred = GlobalScope.async {
            println("Throwing exception from async")
            throw ArithmeticException("exception from async")
        }
        try {
            deferred.await()
        }catch (e:java.lang.ArithmeticException){
            println("Caught in ArithmeticException ${e.localizedMessage}")

        }

    }
}