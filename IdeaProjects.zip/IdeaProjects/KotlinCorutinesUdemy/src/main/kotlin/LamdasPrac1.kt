package org.example

fun main() {
    val list = listOf(1,2,3,4,5,6)



//    val modeOperation:(Int)->Boolean = { a: Int -> a % 2 == 0 }
//    println(modeOperation(7))

//    val outPut = higherOrderFunction(2.0, 4.0) { a: Double, b: Double -> a + b }
//    println(outPut)
//
//    val myFn = higherOrderFn(2.0, 4.0, ::add)
//    println(myFn)


//    val addd: (Int, Int) -> Unit = { a: Int, b: Int -> a + b }
//    println(addd(3, 5))

    inlineFunction { println("calling inline function") }



}


fun higherOrderFunction(a: Double, b: Double, fn: (Double, Double) -> Double): Double {
    return fn(a, b)
}

fun add(a: Double, b: Double): Double {
    return a + b
}

fun higherOrderFn(a: Double, b: Double, fn: (Double, Double) -> Double): Double {
    print(fn(a, b))
    return fn(a, b)
}

inline fun inlineFunction(fn: () -> Unit) {
    fn()
    println("Code inside inline functionmmkmmdmkmc")

}

