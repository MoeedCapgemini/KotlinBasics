package org.example

fun main() {
    val code1 = Code()
    code1.channelName = "Code With"
    code1.printIt()

    val code2 = Code()
    code2.channelName = "Yash"
    code2.printIt()

    val code3 = code1.add(code2)
    code3.printIt()

}

fun Code.add(codeParams:Code):Code{
    val codeObj = Code()
    codeObj.channelName =  this.channelName+" "+codeParams.channelName
    return codeObj

}

class Code {
    var channelName: String? = null
    fun printIt() {
        println(channelName)
    }

}