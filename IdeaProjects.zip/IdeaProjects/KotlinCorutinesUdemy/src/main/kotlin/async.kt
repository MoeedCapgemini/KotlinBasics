package org.example

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlin.random.Random

fun main() {
    runBlocking {
        val firstDeffered = async { getFirstValue() }
        val secondDeffred = async { getSecondValue() }
    }
}

suspend fun getFirstValue():Int{
    delay(1000L)
    val value = Random.nextInt(100)
    println("Returning first value $value")
    return value
}

suspend fun getSecondValue():Int{
    delay(2000L)
    val value = Random.nextInt(1000)
    println("Returning first value $value")
    return value


}