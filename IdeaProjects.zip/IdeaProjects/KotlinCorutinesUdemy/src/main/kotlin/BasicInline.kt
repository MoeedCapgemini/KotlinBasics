package org.example

fun main() {
    message {
        println("This is message11111")
        return@message
    }
    message { println("This is second message") }

}

inline fun message(noinline a: () -> Unit) {
    a.invoke()
}