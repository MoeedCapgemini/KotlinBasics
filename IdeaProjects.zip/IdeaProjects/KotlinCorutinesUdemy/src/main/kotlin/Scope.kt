package org.example

import kotlinx.coroutines.*

fun main() {
    println("Program execution will now block")
    runBlocking {
        launch {
            delay(1000L)
            println("Task from run Blocking")
        }

        GlobalScope.launch {
            delay(500L)
            println("Task from Global Scope")
        }

        coroutineScope {
            launch {
                delay(1500L)
                println("Task from coroutines scope")
            }
        }

    }
    println("Program execution will now continue")
}