package org.example

fun main() {
    val sentence = "Hello World from"
    var result = ""
    var word = ""

    for (i in sentence.indices) {
        if (sentence[i] == ' ') {
            result += reverseWord(word) + " "
            word = ""
        } else {
            word += sentence[i]
        }
    }
    result += reverseWord(word)

}

fun reverseWord(word: String): String {
    var reversed = ""
    for (i in word.length - 1 downTo 0) {
        reversed += word[i]  // Append each character in reverse order
    }
    return reversed
}