package org.example

fun reverseString(string: String):String{
    if (string.isEmpty()){
        return string
    }else
    {
        return reverseString(string.substring(1))+string[0]
    }
}