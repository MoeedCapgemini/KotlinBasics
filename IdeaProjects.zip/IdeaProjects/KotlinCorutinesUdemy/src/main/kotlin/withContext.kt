package org.example

import kotlinx.coroutines.*

fun main() {

    runBlocking {
        val job = launch {
            delay(1000L)
            println("Task from launch")
        }

        val deferred = async {
            delay(1000L)
            "Task from async"
        }
        println(deferred.await())
        job.join()
    }

    /*runBlocking {
        coroutineScope {
            launch {
                delay(1000L)
                println("Task from nested launch")
            }
            delay(1000L)
            println("Task from coroutine scope")
        }
        println("Out Side Coroutine scope")
    }*/

    /*runBlocking {
        launch(Dispatchers.Default) {
            println("First Context :$coroutineContext")
            withContext(Dispatchers.IO){
                println("Second Context :$coroutineContext")
            }
            println("Third Context :$coroutineContext")
        }
    }*/
}