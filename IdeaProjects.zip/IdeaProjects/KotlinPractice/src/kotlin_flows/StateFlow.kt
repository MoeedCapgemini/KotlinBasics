package kotlin_flows

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        launch {
            val result = stateFlow().value
            println(result)
            stateFlow().collect{
                delay(5000)
                println("Collecting1111 $it")
            }
        }

        launch {
            stateFlow().collect{
                delay(5000)
                println("Collecting2222 $it")
            }
        }

    }

}

private fun stateFlow(): StateFlow<Int> {
    val mutableStateFlow = MutableStateFlow<Int>(10)
    val list = listOf(1, 2, 3, 4, 5, 6, 7)
    GlobalScope.launch {
        list.forEach {
            mutableStateFlow.emit(it)
            delay(100)
        }
    }
    return mutableStateFlow
}