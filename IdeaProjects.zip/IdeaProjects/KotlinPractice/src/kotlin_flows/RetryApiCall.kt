package kotlin_flows

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.retry
import kotlinx.coroutines.runBlocking
import java.io.IOException

fun main() = runBlocking {
    fetchDataFromNetwork().collect {
        println("$it")
    }


}

fun fetchDataFromNetwork(): Flow<String> = flow {
    println("Attempting network call")
    if (Math.random() < 0.7) {
        throw IOException("Network Error")
    }
    emit("Success")
}.retry(retries = 3) { cause ->
    cause is IOException

}.catch {
    emit("failed after retries :${it.message}")
}

fun fetchDataFromApiCall(): Flow<String> = flow {
    println("Calling Api")
    if (Math.random() < 0.8) {
        throw IOException("Network Error")
    }
    emit("Success")
}.retry(retries = 3) { cause ->
    cause is IOException

}.catch {
    emit("Failed after retries ${it.message}")
}