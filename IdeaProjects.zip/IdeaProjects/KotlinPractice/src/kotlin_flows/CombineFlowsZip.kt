package kotlin_flows

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.zip
import kotlinx.coroutines.runBlocking

/*1.
Using zip
Combines the emissions of two flows into pairs.
*/

fun main(): Unit = runBlocking {

    val flow1 = flow {
        emit(1)
        delay(5000)
        emit(2)
    }
    val flow2 = flow {
        delay(50)
        emit("A")
        delay(100)
        emit("B")
    }
    flow1.combine(flow2) { a, b -> "$a->$b" }
        .collect {
            println("$it")
            delay(100)
        }

}