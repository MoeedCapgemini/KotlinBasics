package kotlin_flows

import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun main():Unit= runBlocking {
    exampleFlow()
        .onEach {
            println("Received Value $it")
        }
        .catch {
            println("Caught exception: ${it.message}")
        }
        .onCompletion {cause ->
            if (cause!=null){
                println("Flow completed with exception ${cause.message}")
            }
            else{
                println("Flow comppleted Successfully")
            }

        }
        .collect()

}

fun exampleFlow(): Flow<Int> = flow {
    for (i in 1..5) {
        if (i == 3) throw RuntimeException("Something went wrong at$i")
        emit(i)
    }
}