package kotlin_flows

import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        handleException().collect{
            println(it)
        }
    }

}

fun handleException() = flow {
    for (i in 1..6){
        if (i==4)throw RuntimeException("Something went wrong:$i")
        emit(i)
    }
}.catch {
    println("caught exception:${it.message.toString()}")
    emit(-1)
}.onCompletion {cause ->
    if (cause==null){
        println("Flow completed successfully")
    }else{
        print("Flow completed with some exception ${cause.message}")
    }

}