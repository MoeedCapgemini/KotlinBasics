package kotlin_flows

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun main()= runBlocking {



    /*val fruits = listOf("Mango","Orange","Papaya","Pineapple")
    val flow = fruits.asFlow()
    flow.collect{
        println("Received fruits: $it")
    }*/

    /*val flow = flowOf("Apple","Orange","Cherry")
    flow.collect{fruit->
        println("Received :$fruit")
    }*/

    numberFlow()
        .take(5)
        .collect{
            println("Received:$it")
        }

}

fun numberFlow():Flow<Int> = flow {
    for (i in 1..7){
        emit(i)
        delay(1000)
    }
}

