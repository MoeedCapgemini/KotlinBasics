package kotlin_flows

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        numberFloww()
            .flowOn(Dispatchers.IO)
            .collect{
                println("InsideCollect :${Thread.currentThread().name}")
                println("Received:$it")
            }
    }


}

fun numberFloww() = flow {
    println("Emitting on ${Thread.currentThread().name}")
    emit("Hello")
}