package kotlin_flows

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow

fun main():Unit = runBlocking {

        launch {
            val result = producer()
            result.collect{
                println("FIRST- $it")
            }
        }

        launch {
            val result = producer()

            result.collect{
                delay(2500)
                println("SECOND- $it")
            }
        }
}

private fun producer(): Flow<Int> {
    val mutableSharedFlow = MutableSharedFlow<Int>(0)
    val list = listOf(1, 2, 3, 4, 5, 6, 7, 8)
    GlobalScope.launch {
        list.forEach {
            mutableSharedFlow.emit(it)
            delay(1000)
        }
    }
    return mutableSharedFlow
}
