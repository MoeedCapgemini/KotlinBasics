package kotlin_flows

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main(): Unit = runBlocking {
    launch {
        val result = numberFlowing().value
        println(result)
        numberFlowing().collect{
            delay(2000)
            println("O:$it")
        }
    }

    launch {
        val result = numberFlowing().value
        println(result)
        numberFlowing().collect{
            delay(1000)
            println("TWO:$it")
        }

    }
}

fun numberFlowing(): StateFlow<Int> {
    val mutableStateFlow: MutableStateFlow<Int> = MutableStateFlow(4)
    val list = listOf(1, 2, 3, 4, 5, 6, 7, 8)
    GlobalScope.launch {
        list.forEach {
            mutableStateFlow.emit(it)
            delay(1000)
        }
    }
    return mutableStateFlow
}

