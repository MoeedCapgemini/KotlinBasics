package kotlin_flows

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.runBlocking

fun main():Unit= runBlocking {
    handlingExceptionInFlow()
        .collect{
            println("Collecting Values: $it")
        }

}

fun handlingExceptionInFlow() = flow {
    val list = listOf(1, 2, 3, 4, 5, 6, 7, 8)
    list.forEach {
        if (it != 4) {
            emit(it)
            delay(1000)
        } else {
            throw RuntimeException("Exception occurred at $it")
        }
    }
}.onEach {
    println("Emitting values $it until 4")
}
    .catch {
        println("Caught exception :${it.message.toString()}")
        emit(-5)
        emit(-6)
    }
    .onCompletion {cause ->
        if (cause == null){
            println("Flow completed successfully")
        }else
        {
            println("Flow completed with some exception ${cause.message}")
        }

    }