package kotlin_flows

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.runBlocking

fun main(): Unit = runBlocking {
    launchInFun()
        .onEach {
            println("LAUNCHING: $it")
        }.launchIn(this)


}

fun launchInFun(): Flow<Int> = flow {
    for (i in 1..10) {
        delay(1000)
        emit(i)
    }
}