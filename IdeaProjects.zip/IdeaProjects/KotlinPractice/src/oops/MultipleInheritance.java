package oops;

interface Sound{
    void noise();
}

interface Dhol{
    void noise();
}

class Music implements Sound,Dhol{

    @Override
    public void noise() {
        System.out.println("making sound");
    }

    /*public static void main(String[] args) {
        Music music = new Music();
        music.noise();
    }*/
}
