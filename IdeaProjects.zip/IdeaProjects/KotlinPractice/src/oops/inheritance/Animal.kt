package oops.inheritance

open class Animal(val name:String){
    open fun makeSound(){
        println("$name makes a sound")
    }

    fun sleep(){
        println("$name is sleeping")
    }
}

class Dog(name: String):Animal(name){
    override fun makeSound() {
        println("$name barks")
    }

    fun fetch(){
        println("$name is fetching the ball")
    }
}

class Cat(name: String):Animal(name){
    override fun makeSound() {
        println("$name meows")
    }

    fun scratch(){
        println("$name scratching the furniture")
    }
}

fun main() {
    val dog = Dog("Buddy")
    dog.makeSound()
    dog.fetch()
    dog.sleep()

    val cat = Cat("Whiskers")
    cat.makeSound()
    cat.scratch()
    cat.sleep()

}