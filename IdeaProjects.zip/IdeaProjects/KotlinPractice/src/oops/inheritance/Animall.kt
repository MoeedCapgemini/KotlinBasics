package oops.inheritance

open class Animall(val name:String) {
    open fun sound() {
        println("$name make sound")
    }

    fun sleep(){
        println("$name is sleeping")
    }


}

class Horse(name: String) : Animall(name) {
    override fun sound() {
        println("$name sound")
    }
}

fun main() {
    val horse = Horse("Horse")
    horse.sound()
    horse.sleep()
}