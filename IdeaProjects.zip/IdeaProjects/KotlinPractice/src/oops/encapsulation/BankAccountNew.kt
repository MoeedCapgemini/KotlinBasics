package oops.encapsulation

class BankAccountNew {
    private var balance: Double = 0.0

    fun deposit(amount: Double) {
        if (amount > 0) {
            balance += amount
        }
    }

    fun getBalance(): Double {
        return balance
    }
}

fun main() {
    val bankAccountNew = BankAccountNew()
    bankAccountNew.deposit(100.0)
    val remBalance = bankAccountNew.getBalance()
    println(remBalance)
}