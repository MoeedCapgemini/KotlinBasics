package oops.encapsulation

/*Encapsulation is the practice of bundling data (properties) and methods (functions) that operate on that data into a single unit (class), and restricting direct access to some of the object's components.*/


class BankAccount(private var balance: Double) {
    fun getBalance(): Double {
        return balance
    }

    fun deposit(amount:Double){
        if (amount>0){
            balance += amount
            println("Deposite $amount. New Balance is $balance")
        }else{
            println("Invalid deposit amount.")
        }
    }

    fun withdraw(amount: Double){
        if (amount>0 && amount<=balance){
            balance -= amount
            println("Withdraw amount is $amount remaining balance is $balance")
        }else{
            println("Insufficient balance")
        }
    }

}

fun main() {
    val bankAccount = BankAccount(100.0)
    bankAccount.deposit(100.0)
    bankAccount.withdraw(10.0)
    println("Current balance is ${bankAccount.getBalance()}")
}