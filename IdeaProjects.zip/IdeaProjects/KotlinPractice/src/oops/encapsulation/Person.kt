package oops.encapsulation

/*Definition: Encapsulation is the practice of bundling data (variables) and methods (functions) that operate on the data into a single unit, typically a class.
It also involves restricting direct access to some of the object's components.

Goal: To protect the internal state of an object and only expose what is necessary.*/

class Person {
    private var name: String = ""
    private var age: Int = 9

    fun setName(newName: String) {
        name = newName
    }

    fun getName(): String {
        return name
    }

    fun setAge(newAge: Int) {
        if (newAge > 0) {

            age = newAge
        }
    }

    fun getAge(): Int {
        return age
    }
}

fun main() {
    val person = Person()
    person.setAge(28)
    println("AGE-${person.getAge()}")
}

