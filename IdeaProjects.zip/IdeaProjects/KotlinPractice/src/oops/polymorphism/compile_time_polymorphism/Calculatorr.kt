package oops.polymorphism.compile_time_polymorphism

//Android Example log(message:String) log(tag:String,message:String)
class Calculatorr{
    fun add(a:Int,b:Int):Int{
        return a+b
    }

    fun add(a:Double,b:Double):Double{
        return a+b
    }

    fun add(a:Int,b:Int,c:Int):Int{
        return a+b+c
    }
}

fun main() {
    val calculatorr = Calculatorr()
    val res = calculatorr.add(2, 4)
    println(res)
}

