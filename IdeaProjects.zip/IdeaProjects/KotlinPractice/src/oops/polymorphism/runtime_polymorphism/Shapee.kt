package oops.polymorphism.runtime_polymorphism

//Demonstrating here is runtime polymorphism through method overriding
//Real Android Example Sealed class UIState types

open class Shapee{
    open fun draw(){
        println("Drawing shape")
    }
}

class Triangle :Shapee(){
    override fun draw() {
        println("Drawing triangle")
    }
}

class Square :Shapee(){
    override fun draw() {
        println("Drawing square")
    }
}
class Circle:Shapee(){
    override fun draw() {
        println("Drawing Circle")
    }
}

fun drawShape(shapes:List<Shapee>){
    for (shape in shapes){
        shape.draw()
    }
}


fun main() {
    val shapes= listOf(Circle(),Square(),Triangle())
    drawShape(shapes)

}

