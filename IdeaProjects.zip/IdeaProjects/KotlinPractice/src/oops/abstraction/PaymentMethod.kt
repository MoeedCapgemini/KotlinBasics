package oops.abstraction


//Abstract class representing a generic payment method
//🎯 Benefits of Abstraction
//Improves code readability and maintainability
//Reduces code duplication
//Enhances security by exposing only necessary parts
//Supports scalability and easier testing

abstract class PaymentMethod {
    abstract fun pay(amount: Double)
    fun showTransactionId() {
        println("Transaction Id :${System.currentTimeMillis()}")
    }
}


class CreditCardPayment : PaymentMethod() {
    override fun pay(amount: Double) {
        println("Paid amount $amount using ICICI Credit Card")
    }

}

class PayPay : PaymentMethod() {
    override fun pay(amount: Double) {
        println("Paid amount $amount using PayPal Credit Card")
    }

}

fun main() {
    val creditCardPayment: PaymentMethod = CreditCardPayment()
    creditCardPayment.pay(200.0)
    creditCardPayment.showTransactionId()

    val paymentMethod: PaymentMethod = PayPay()
    paymentMethod.pay(30.0)
    paymentMethod.showTransactionId()

}

