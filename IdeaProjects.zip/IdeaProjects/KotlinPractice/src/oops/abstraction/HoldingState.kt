package oops.abstraction


interface  Vehicle{
    var speed:Int
    abstract fun drive()
}
fun main() {

}