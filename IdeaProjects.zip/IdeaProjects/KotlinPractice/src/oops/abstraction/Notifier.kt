package oops.abstraction

//Interface defining the abstraction
//interface BaseInterface{
//val loading = MutableLiveData<Boolean>() //Error backing fields not allowed
// }
//

interface Notifier{
    fun sendNotification(message:String)
}

class EmailNotifier :Notifier{
    override fun sendNotification(message: String) {
        println("Email Notification:$message")
    }

}
class SMSNotifier:Notifier{
    override fun sendNotification(message: String) {
        println("SMS notification sent :$message")
    }

}

fun main() {
    val notifier:Notifier = EmailNotifier()
    notifier.sendNotification("EMAIL SENT")

    val smsNotifier:Notifier = SMSNotifier()
    smsNotifier.sendNotification("SMS SENT")
}




/*
interface Notifier {
    fun sendNotification(message: String)
}

//Concrete implementation for Email
class EmailNotifier:Notifier{
    override fun sendNotification(message: String) {
        println("Email notification sent: $message")
    }
}

//Concrete implementation for SMS
class SMSNotifier :Notifier{
    override fun sendNotification(message: String) {
        println("SMS notification sent: $message")
    }
}

//Client Code
fun main() {
    val emailNotifier:Notifier = EmailNotifier()
    emailNotifier.sendNotification("Welcome to our app")

    val smsNotifier:Notifier = SMSNotifier()
    smsNotifier.sendNotification("Your OTP is 1234")

}*/
