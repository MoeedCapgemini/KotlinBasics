package oops;

public class Dog {
    private String name;
    private int age;

    Dog(String name,int age){
        this.name = name;
        this.age = age;
    }

   /* public static void main(String[] args) {
        Dog dog = new Dog("Max",3);

    }*/
}

