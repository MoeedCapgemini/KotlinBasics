package miscellaneous//In Kotlin, composition refers to a design principle where one class contains instances of other classes to reuse their
// functionality. Instead of using inheritance (which is another way to create relationships between
// classes), composition is generally preferred because it promotes a more flexible and modular design.

class Engine(){
    fun start(){
        println("Engine is starting")
    }
    fun stop(){
        println("Engine is stopping")
    }
}

class SedanCar(private val engine: Engine){
    fun drive(){
        engine.start()
        println("Car is driving")
    }

    fun park(){
        engine.stop()
        println("Car is parked")
    }

}

fun main() {
    val engine = Engine()
    val sedanCar = SedanCar(engine)
    sedanCar.drive()
    sedanCar.park()
}