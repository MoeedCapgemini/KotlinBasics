package miscellaneous

fun String.countVowels(): Int {
    var count = 0
    for (ch in this) {
        if (ch in "aeiouAEIOU") {
            count++
        }
    }
    return count
}

data class Person(val name: String, val age: Int)

fun Person.isAdult(): Boolean {
    return this.age >= 18
}

fun main() {

    println(" H E L L O ".removeExtraSpace())

    val text1 = " Hello World "
    val result1 = text1.removeSpaces()
    println(result1)

  /*
    var name: String = "Alice"  //non-nullable can't hold null
    var address: String? = null  //nullable hold both string and null
    val length = address?.length
    println(length)

    val len = address?.length?:0
    println(len)

//    val lengthh = address!!.length
//    println(lengthh)

    greet("---------------Moeed")





    val person = Person("Moeed", 32)
    println("${person.name} is adult : ${person.isAdult()}")
    val text = "Hello Moeed"
    println("Number of vowels: ${text.countVowels()}")

    */
}

fun greet(name: String){
    println("Hello,$name!")
}

fun String.removeSpaces():String{
    return this.replace(" ","")
}

fun String.removeExtraSpace():String{
    return this.replace(" ","")
}

