package miscellaneous
sealed class Result {
    data class Success(val data: String) : Result()
    data class Error(val message: String) : Result()
}

fun processResult(result: Result) {
    when (result) {
        is Result.Success -> println("Data:${result.data}")
        is Result.Error -> println("Error:${result.message}")
    }
}

fun fibonacciPrint(n: Int) {
    var a = 0
    var b = 1
    var c: Int
    println("Fibonacci series upto $n terms")

    for (i in 0..<n){
        if (i<=1){
            println("$i")
        }
        else{
            c = a+b
            a = b
            b= c
            println("$c")
        }
    }
}

fun fibonacy(n:Int):List<Int>{
    val fib = mutableListOf(0,1)
    for (i in 2..<n){
        fib.add(fib[i-1]+fib[i-2])

    }
    return fib
}

fun fibonacci(n: Int): List<Int> {
    val fibSeries = mutableListOf(0, 1)
    for (i in 2..<n) {
        fibSeries.add(fibSeries[i - 1] + fibSeries[i - 2])
    }
    return fibSeries
}


fun main() {
//    fibonacciPrint(10)

    val n = 10
    val result = fibonacci(n)
    println("Fibonacci series upto $n terms :$result")


//    val successResult = Result.Success("Some data")
//    val errorResult = Result.Error("Something went wrong")
//
//    processResult(successResult)
//    processResult(errorResult)
}