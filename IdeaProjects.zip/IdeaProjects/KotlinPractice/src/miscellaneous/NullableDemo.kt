package miscellaneous

fun main() {
    var country: String? = null

//    if (country != null){
//        println(country.length)
//    }

    //Safe Call
    //println(country?.length)
//    country?.let {
//        println(country.length)
//
//    }

    //Elvis Operator
  //  println(country?.length ?: 0)

    //Not null assertion operator
    println(country!!.length)
}