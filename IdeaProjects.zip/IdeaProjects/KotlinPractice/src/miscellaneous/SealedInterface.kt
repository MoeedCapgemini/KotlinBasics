package miscellaneous

sealed interface SomeExtra{
    fun logExtra()
}

sealed class SealedLog :SomeExtra{
    class Log :SealedLog() {
        override fun logExtra() {
            println("Sealed class impl")
        }
    }
}

enum class SealedEnum : SomeExtra{
    Log{
        override fun logExtra() {
            print("enum impl")
        }

    }
}

fun main() {
    val sealedLog = SealedLog.Log()
    sealedLog.logExtra()

    val sealedEnum = SealedEnum.Log
    sealedEnum.logExtra()
}