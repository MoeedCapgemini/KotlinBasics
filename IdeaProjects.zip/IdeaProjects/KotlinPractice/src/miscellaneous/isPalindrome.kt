package miscellaneous

fun isPalindromeNumber(x: Int): Boolean {
    val cleanedInput = x.toString()
    var left = 0
    var right = cleanedInput.length - 1
    while (left < right) {
        if (cleanedInput[left] != cleanedInput[right]) {
            return false
        }
        left++
        right--
    }
    return true
}


fun main() {
    val input = 121
    if (isPalindromeNumber(input)) {
        println("The string is a palindromejMOEEEEDDDD.")
    } else {
        println("The string is not a palindhhABDULLLLLLL.")
    }

}
