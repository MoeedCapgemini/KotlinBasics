package miscellaneous

enum class EnumLoggerLevel(val message: String) {
    LOW(message = "Low Warming"), //0
    MEDIUM("Medium Warning"),//1
    HIGH("High Warning")  //2
}

sealed class SealedLoggerLevel(val message: String) {
    class Low(message: String) : SealedLoggerLevel(message)
    class Medium(message: String) : SealedLoggerLevel(message)
    class High(message: String) : SealedLoggerLevel(message)
}

fun main() {

    val enumType = EnumLoggerLevel.LOW
    when (enumType) {
        EnumLoggerLevel.LOW -> println(enumType.message)
        EnumLoggerLevel.MEDIUM -> println(enumType.message)
        EnumLoggerLevel.HIGH -> println(enumType.message)
    }

    val lowSealed :SealedLoggerLevel = SealedLoggerLevel.Low("Low Sealed")

    when(lowSealed){
        is SealedLoggerLevel.High -> println(lowSealed.message)
        is SealedLoggerLevel.Low -> println(lowSealed.message)
        is SealedLoggerLevel.Medium -> println(lowSealed.message)
    }
}