package miscellaneous

fun startAndEndsWithVowels(word: String): Boolean {
    val vowels = "AEIOUaeiou"
    return word.isNotEmpty() && vowels.contains(word.first()) && vowels.contains(word.last())
}

fun main() {
    val words:List<String> = listOf("apple", "orange", "banana", "audi", "elephant")
    for (word in words){
        if (startAndEndsWithVowels(word)){
            println("$word starts and end with vowel.")
        }
    }

}