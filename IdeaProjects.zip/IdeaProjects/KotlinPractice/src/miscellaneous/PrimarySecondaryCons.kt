package miscellaneous

class Mentor(firstName: String, lastName: String) {
    init {
        println("First init block : $firstName")
    }

    private val fullName = "$firstName $lastName".also { println("Full Name Property") }

    init {
        println("Second init block :${fullName.length}")
    }

    constructor(firstName: String, lastName: String, interest: String) : this(firstName, lastName) {
        println("Secondary constructor:$interest")
    }
}

fun main() {
    val mentor = Mentor("Abdul","Moeed","Tech")
}

