package miscellaneous

interface Vehicle {
    fun start()
}

class Car : Vehicle {
    override fun start() {
        println("Car is Starting")
    }
}

class Bike : Vehicle {
    override fun start() {
        println("Bike is starting")
    }
}

fun main() {
    var car: Vehicle = Car()
    car.start()

    val bike: Vehicle = Bike()
    bike.start()
}