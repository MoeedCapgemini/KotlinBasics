package miscellaneous//Bubble sort repeatedly steps through the list,compares adjacent elements and
// swaps them if they are in wrong order. It is insufficient for large data sets


fun bubbleSort1(list: MutableList<Int>) {
    val n = list.size
    for (i in 0 until n - 1) {
        for (j in 0 until n - 1 - i) {
            if (list[j] < list[j + 1]){
                val temp = list[j+1]
                list[j+1] = list[j]
                list[j] = temp
            }
        }
    }
}

fun bubbleSort(list: MutableList<Int>) {
    val n = list.size
    for (i in 0 until n - 1) {
        for (j in 0 until n - 1 - i) {
            if (list[j] > list[j + 1]) {
                val temp = list[j]
                list[j] = list[j+1]
                list[j+1] = temp
            }
        }
    }

}


fun main() {
    val numbers = mutableListOf(12, 11, 13, 5, 6, 7)
    bubbleSort(numbers)
    println(numbers)

    /*val numbers = listOf(12, 11, 13, 5, 6, 7)
    val sortedNumbers = numbers.sorted() // Returns a sorted list
    println(sortedNumbers) // Output: [5, 6, 7, 11, 12, 13]*/

}


