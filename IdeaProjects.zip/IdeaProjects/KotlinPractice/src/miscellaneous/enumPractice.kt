package miscellaneous//Enum is a special type of class used to define a collection of Constants.
// It is typically used when you need to represent a fixed set of relative values.
//Example Days of the week,colors,directions,or status code

enum class Directions(private val abbreviation:String){
    NORTH("N"),
    EAST("E"),
    SOUTH("S"),
    WEST("W");

    fun description(){
        println("Direction is $name with abbreviation $abbreviation")

    }

}

fun getDirectionDescription(directions: Directions):String{
    return when(directions){
        Directions.WEST->"WEST Direction"
        Directions.NORTH -> "NORTH Direction"
        Directions.EAST -> "EAST Direction"
        Directions.SOUTH -> "SOUTH Direction"
    }
}

fun main(){
    val myDirection = Directions.WEST
    println(myDirection.description())

    println(getDirectionDescription(Directions.WEST))
}