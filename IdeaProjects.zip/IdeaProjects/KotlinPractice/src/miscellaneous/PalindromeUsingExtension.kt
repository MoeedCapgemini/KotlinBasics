package miscellaneous

val String.isPalindrom: Boolean
    get() = this == this.reversed()


fun main() {
    val word = "nitin"
    println(word.isPalindrom)
}