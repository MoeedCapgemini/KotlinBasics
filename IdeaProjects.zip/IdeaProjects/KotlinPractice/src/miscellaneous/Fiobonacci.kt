package miscellaneous

fun main() {
    val n = 10
    val fbNumbers = fibonaccii(n)
    println("Fibonacci series up to $n terms:$fbNumbers")
}

fun fibonaccii(n: Int): List<Int> {
    val fibList = mutableListOf(0, 1)
    for (i in 2 until n) {
        fibList.add(fibList[i - 1] + fibList[i - 2])
    }
    return fibList
}

fun fibo(n: Int): List<Int> {
    val fiboList = mutableListOf(0, 1)
    for (i in 2 until n) {
        fiboList.add(fiboList[i - 1] + fiboList[i - 2])
    }
    return fiboList
}