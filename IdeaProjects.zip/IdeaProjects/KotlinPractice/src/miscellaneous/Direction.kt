package miscellaneous

enum class Direction {
    NORTH, SOUTH, EAST, WEST
}



fun printDirection(direction: Direction) {
    when (direction) {
        Direction.WEST -> println("Going WEST")
        Direction.NORTH -> println("Going NORTH")
        Direction.SOUTH -> println("Going SOUTH")
        else -> println("Unknown direction")
        //Direction.EAST -> println("Going EAST")

    }
}

fun main() {
    val direction = Direction.WEST
    printDirection(direction)
}