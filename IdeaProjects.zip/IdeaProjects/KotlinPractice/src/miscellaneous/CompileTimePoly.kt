package miscellaneous

fun main() {
    //greeting("Moeed")
    //greeting("Moeed", 92)

    add(2,4,::addition)

}

fun greeting(name: String) {
    println("Hello $name")
}

fun greeting(name: String, age: Int) {
    println("Hello, $name! You are $age years old")
}

fun addition(a:Int,b:Int):Int{
    return a+b
}

fun add(a:Int,b:Int,fn:(Int,Int)->Int){
    println(fn(a,b))
}