package miscellaneous

fun secondLargestNumber(numbers: List<Int>): Int? {
    if (numbers.size < 2) return null
    var largest = Int.MIN_VALUE
    var secondLargest = Int.MIN_VALUE
    for (num in numbers) {
        when {
            num > largest -> {
                secondLargest = largest
                largest = num
            }

            num > secondLargest && num != largest -> {
                secondLargest = num
            }
        }
    }
    return if (secondLargest == Int.MIN_VALUE) null else secondLargest
}


fun findSecondLargest(numbers: List<Int>): Int? {
    if (numbers.size < 2) return null
    var largest = Int.MIN_VALUE
    var secondLargest = Int.MIN_VALUE
    for (num in numbers) {
        when {
            //100,20,45,45,99
            num > largest -> {
                secondLargest = largest     //20 45
                largest = num       //100

            }
            //100,20,45,45,99

            num > secondLargest && num != largest -> {
                secondLargest = num

            }
        }
    }
    return if (secondLargest == Int.MIN_VALUE) null else secondLargest
}

fun main()  {
    val numbers = listOf(100)
    val secondLargest = findSecondLargest(numbers)
    println("Second Largest number is $secondLargest")
}

/*fun main(): Unit = runBlocking {

    coroutineScope {

        launch {

            delay(1000L)

            println("Task from nested launch")

        }

        delay(1000L)

        println("Task from coroutine scope")

    }

    println("Out Side Coroutine scope")

}*/

