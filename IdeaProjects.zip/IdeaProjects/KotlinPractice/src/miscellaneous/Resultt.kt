package miscellaneous//In Kotlin, a sealed class is a special kind of class that restricts the class hierarchy.
// It can only be subclassed within the same file where it is declared, which makes it useful
// when you want to represent a restricted class hierarchy (i.e., a set of types with a limited number of
// subclasses).
//
//Sealed classes are particularly useful for handling various states or outcomes in Android, such as
// managing different UI states, representing success or error states in a network request,
// or implementing more structured flow in a ViewModel.

//sealed class can have multiple subclasses (e.g., Success, Error, and Loading in the above example).
//It allows exhaustiveness checks in when expressions. You can handle each possible subclass of the sealed class explicitly,
// making it safer and more predictable.
//Subclasses of a sealed class must be declared within the same file, which limits the possible subclasses,
// making it easier to reason about the code.


//Example 1: Sealed class for handling network responses

sealed class NetworkResult<out T> {
    data class Success<out T>(val data: T) : NetworkResult<T>()
    data class Error(val exception: Throwable) : NetworkResult<Nothing>()

    object Loading : NetworkResult<Nothing>()
}

sealed class NetworkStatus<out T> {
    data class Success<out T>(val data: T) : NetworkStatus<T>()
    data class Error(val exception: Throwable) : NetworkStatus<Nothing>()
    object Loading : NetworkStatus<Nothing>()
}

