package miscellaneous//The word ‘polymorphism’ means ‘having many forms’.
// In Java, polymorphism refers to the ability of a message to be displayed in more than one form.
// This concept is a key feature of Object-Oriented Programming
// and it allows objects to behave differently based on their specific class type.
//
//Real-life Illustration of Polymorphism in Java: A person can have different characteristics at the same
// time. Like a man at the same time is a father, a husband, and an employee. So the same person possesses
// different behaviors in different situations. This is called polymorphism.
//
//Example: A Person Having Different Roles

open class Animal{
    open fun makeSound(){
        println("Animal makes a sound")
    }
}

class Dog :Animal(){
    override fun makeSound() {
        //super.makeSound()
        println("Dog barks ")
    }
}

class Cat :Animal(){
    override fun makeSound() {
      // super.makeSound()
        println("Cat meows")
    }
}

fun main() {
//    val animal:Animal = Dog()
//    animal.makeSound()

    val anotherAnimal:Animal = Cat()
    anotherAnimal.makeSound()
}


