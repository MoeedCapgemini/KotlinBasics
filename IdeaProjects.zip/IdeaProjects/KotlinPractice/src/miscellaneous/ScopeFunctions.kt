package miscellaneous

data class User(var name: String = "", var age: Int = 18)

fun main() {
    val user = User()
    user.name = "John"
    user.age = 20

    val x = user.apply {
        age = 10
        name = "seanssss"
    }

    var xLet = user.let {
        println(it.age)
        println(it.name)
    }

}