package miscellaneous

fun isSubstringPresent(str1: String, str2: String): Boolean {
    return str1.contains(str2)
}

fun main() {
    val str1 = "padmaja"
    val str2 = "maj"
    val result = isSubstringPresent(str1, str2)
    if (result) {
        println("The String $str1 is a substring of $str2")
    } else {
        println("The String $str1 is NOT a substring of $str2")

    }
}