package miscellaneous

import java.util.Date

data class Session @JvmOverloads constructor(@JvmField val name: String, val date: Date = Date())

fun main() {
    val session1 = Session("Moeed", Date())
    val name = session1.name
    val session2 = Session("Helooo")
}