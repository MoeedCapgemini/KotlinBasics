package miscellaneous

fun reverseArrayFromIndex(arr: IntArray, index: Int): IntArray {
    val prefix = arr.sliceArray(0 until index)
    val suffix = arr.sliceArray(index until arr.size).reversedArray()

    return prefix + suffix
}


fun rotateArray(array: IntArray, rotateFromIndex: Int): IntArray {
    val prefix = array.sliceArray(0 until rotateFromIndex)
    val siffix = array.sliceArray(rotateFromIndex until array.size)
    return siffix + prefix
}


fun moveZerosToEnd(array: IntArray): IntArray {
    var index = 0
    for (i in array.indices) {
        if (array[i] != 0) {
            array[index] = array[i]
            if (index != i) {
                array[i] = 0

            }
            index++
        }
    }
    return array

}

fun moveAllZerosToEnd(array: IntArray): IntArray {
    var index = 0
    for (i in array.indices){
        if (array[i]!=0){
            array[index] = array[i]
            if (index != i){
                array[i] = 0
            }
            index++
        }
    }
    return array

}


fun main() {
    /*{1,2,3,4,5,6}
    {5,6,1,2,3,4}*/

    val arr = intArrayOf(1, 2, 3, 4, 5, 6)//1,2,3,9,8,7,6,5,4
    val index = 4

    val result = rotateArray(arr, index)
    println("Array after rotating from $index : ${result.joinToString(",")}")

      /*var arr = intArrayOf(1, 0, 2, 0, 3, 0, 4, 0, 7, 9, 7, 8)
      val result = moveZerosToEnd(arr)
      println("${result.joinToString(",")}")*/


    /*val arr = intArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9)//1,2,3,9,8,7,6,5,4
    val index = 3

    val result = reverseArrayFromIndex(arr, index)
    println("Array after rotating from $index :${result.joinToString(",")}")*/


//    val result = reverseArrayFromIndex(arr, index)
//    println("Array after reversal from index $index: ${result.joinToString(", ")}")
}