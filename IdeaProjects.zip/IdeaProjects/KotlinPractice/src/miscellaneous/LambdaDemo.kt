package miscellaneous

fun main() {
    val lambda1: (Int, Int) -> Int = { x, y -> x + y }
    val lambda2 = { a: Int, b: Int -> a + b }
    val lambda3: (Int, Int) -> Unit = { x, y -> println(x + y) }
    val greet: () -> Unit = { println("Hello") }

    println(lambda2(2, 3))
    lambda3(2, 3)
    //greet()
    println({a:String,b:String->"$a $b"}("Abdul","Moeed"))

    val myvariable:(String,String)->String = fun(a,b):String{
        return "$a $b"
    }

    println(myvariable("ansbbdb","njdnjndjn"))


    val myAdd = fun(a: Int, b: Int): Int {
        return a + b
    }

    println(myAdd(1, 2))

    val higherOrderVar = higherOrderFn(2,100,::add)
    println(higherOrderVar)

}

fun add(a: Int, b: Int): Int {
    return a + b
}

fun sum(a: Int, b: Int): Int {
    return a + b
}

fun higherOrderFn(a: Int, b: Int, fn: (a: Int, b: Int) -> Int): Int {
    return fn(a, b)

}