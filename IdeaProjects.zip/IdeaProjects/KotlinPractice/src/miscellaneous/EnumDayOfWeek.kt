package miscellaneous

enum class DayOfWeek {
    MONDAY {
        override fun getWorkingHours(): String = "9 AM - 5 PM"
    },
    TUESDAY {
        override fun getWorkingHours(): String = "9 AM - 5 PM"
    },

    SATURDAY {
        override fun getWorkingHours(): String = "CLOSED"
    },
    SUNNDAY {
        override fun getWorkingHours(): String = "CLOSED"
    };

    abstract fun getWorkingHours(): String
}

fun main() {
//    val day = DayOfWeek.SUNNDAY
//    println("SUNDAY WORKING HOURS :${day.getWorkingHours()}")
//
//    val days = DayOfWeek.values()
//    for (day in days){
//        println(day)
//    }

    val whichDay = DayOfWeek.valueOf("MONDAY")
    println(whichDay)

}