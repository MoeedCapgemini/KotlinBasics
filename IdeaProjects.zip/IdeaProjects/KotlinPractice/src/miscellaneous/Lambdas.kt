package miscellaneous

val myLambda: (Int, Int) -> Int = { a, b -> a + b }
val greet: () -> Unit = { println("Hello Kotlinjmkkmkkk!") }
val sum = { a: Int, b: Int -> a + b }


fun main() {
    val text:String? = "Hello"
    text?.let { println(it)  }

    val numbers = listOf(2, 3, 4, 5, 6)
    val squares = numbers.map { it * it }
    println(squares)

//    greet()
//    println(myLambda(9,9))
//    println(sum(2,4))
}