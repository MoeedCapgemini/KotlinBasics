package miscellaneous

fun main() {
    val e1 = Employee("Nitesh", 10000.0)
    val e2 = Employee("Moeed", 10000.0)
    val e3 = e2.copy(salary = 11.0)
    println(e3)
    println(e2.toString())
    println(e1 == e2)
}

data class Employee(val name: String, val salary: Double) {

}