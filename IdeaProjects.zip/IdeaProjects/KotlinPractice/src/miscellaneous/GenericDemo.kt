package miscellaneous

class Box<T>(private val input: T) {

    init {
        println(input)
    }

}


fun <T> myListOf(vararg elements: T): List<T> {
    return elements.asList()
}

fun main() {
    val box1: Box<Int> = Box(12)
    val box2: Box<String> = Box("Moeed")

    val numbers1 = listOf(9, 8, 7)



    val numbers2 = myListOf(1, 2, 3, 4)

    var sum2 = 0
    for (num in numbers2) {
        sum2 += num
    }
    println(sum2)
}