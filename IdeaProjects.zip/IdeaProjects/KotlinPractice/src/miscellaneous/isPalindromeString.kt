package miscellaneous

fun checkForPalindromeInput(input: Any):Boolean{
    if (input is String){
        val cleanedInput = input.filter { it.isLetterOrDigit() }.lowercase()
        var left = 0
        var right = cleanedInput.length-1
        while (left<right){
            if (cleanedInput[left] != cleanedInput[right]){
                return false
            }
            left++
            right--
        }
        return true

    }

    if (input is Int){
        val cleanedInput = input.toString()
        var left = 0
        var right = cleanedInput.length-1
        while (left<right){
            if (cleanedInput[left] != cleanedInput[right]){
                return false
            }
            left++
            right--
        }
        return true
    }
    return false

}



fun isPalindromeString(input: Any): Boolean {
    if (input is String) {
        val cleanedInput = input.filter { it.isLetterOrDigit() }.lowercase()

        var left = 0
        var right = cleanedInput.length - 1
        while (left < right) {
            if (cleanedInput[left] != cleanedInput[right]) {
                return false
            }
            left++
            right--
        }
        return true

    }
    if (input is Int){
       // if (input<0) return false
        val cleanedInput = input.toString()
        var left =0
        var right = cleanedInput.length-1
        while (left<right){
            if (cleanedInput[left]!=cleanedInput[right]){
                return false
            }
            left++
            right--
        }
        return true

    }
    return false

}


fun main() {
    val input = -123
    if (isPalindromeString(input)) {
        println("The string is a palindrome.")
    } else {
        println("The string is not a palindrome.")
    }
}