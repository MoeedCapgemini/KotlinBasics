package relationships

class Book(val title: String)
class Library(val name: String) {
    private val books = mutableListOf<Book>()
    fun addBook(title: String) {
        books.add(Book(title))

    }

    fun showBooks(){
        for (book in books){
            println("Library is $name")
            println("Books is ${book.title}")
        }
    }
}

fun main() {
    val library = Library("City Library")
    library.addBook("Java")
    library.addBook("Android")
    library.showBooks()

}

