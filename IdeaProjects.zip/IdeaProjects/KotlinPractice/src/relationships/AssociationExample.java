package relationships;

class Student {
    String name;

    Student(String name) {
        this.name = name;
    }

    void display() {
        System.out.println("Student name is " + name);
    }



}

class School {
    String schoolName;

    School(String schoolName) {
        this.schoolName = schoolName;
    }

    void showStudent(Student student) {
        System.out.println("School name is :" + schoolName);
        student.display();
    }

}

class Main {
    public static void main(String[] args) {
        Student student = new Student("Moeed");
        School school = new School("Greenwood High");
        school.showStudent(student);

    }
}



