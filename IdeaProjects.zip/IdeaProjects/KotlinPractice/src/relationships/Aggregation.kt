package relationships

//Aggregation

class Professor(val name: String)

class Department(val name: String, val professor: List<Professor>) {
    fun showProfessor() {
        println("Department name is :$name")
        for (professor in professor) {
            println("Professor name is ${professor.name}")
        }

    }
}

fun main() {
    val professor1 = Professor("Moeed")
    val professor2 = Professor("Jack")

    val department = Department("Computer Science", listOf(professor1,professor2))
    department.showProfessor()
}





