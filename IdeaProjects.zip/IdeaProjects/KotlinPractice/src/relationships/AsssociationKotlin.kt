package relationships

//Association
//School HAS-A Student relationship
class Student1(val name:String){
    fun display(){
        println("Student name is: $name")
    }
}

class School1(val schoolName:String){
    fun showStudent(student1: Student1){
        println("School name is :$schoolName")
        student1.display()
    }
}

fun main() {
    val student1 = Student1("MOEED")
    val school1 = School1("BAY")
    school1.showStudent(student1)
}

