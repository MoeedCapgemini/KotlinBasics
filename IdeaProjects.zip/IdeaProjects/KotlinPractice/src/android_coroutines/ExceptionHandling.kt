package android_coroutines

import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/*🔹 What is CoroutineExceptionHandler?
CoroutineExceptionHandler is a special tool in Kotlin coroutines that catches exceptions
that are not handled inside the coroutine itself — these are called uncaught exceptions.*/



fun main():Unit= runBlocking {
     val handler = CoroutineExceptionHandler { _, exception ->
         println("Haandlkeeed ${exception.message}")
     }

    launch(handler) {
        throw RuntimeException("ERRORRRRR")
    }

}