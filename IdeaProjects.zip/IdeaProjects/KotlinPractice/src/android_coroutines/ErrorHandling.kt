package android_coroutines

import kotlinx.coroutines.*

fun main(): Unit = runBlocking {
    val handler = CoroutineExceptionHandler { coroutineContext, throwable ->
        println("Error: ${throwable.message}")
    }

    val job = CoroutineScope(handler).launch {
        supervisorScope {
            launch {
                delay(1000)
                println("CHILD 1")
                throw RuntimeException("Exception in Child 1")
            }

            launch {
                delay(2000)
                println("CHILD 2")

            }

        }
    }
    job.join()

}