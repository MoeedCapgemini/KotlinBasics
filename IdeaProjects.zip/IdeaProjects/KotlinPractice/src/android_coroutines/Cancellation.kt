package android_coroutines

import kotlinx.coroutines.*

fun main(): Unit = runBlocking {
    val parentJob = launch {

        CoroutineScope(Dispatchers.IO).launch {
            try {
                repeat(5) {
                    delay(300)
                    println("Independent coroutine running")
                }
            } finally {
                println("Independent coroutine cancelled")
            }
        }

        coroutineScope {
            launch {
                try {
                    repeat(5) {

                        delay(300)
                        println("Structured coroutine running...")
                    }
                } finally {
                    println("Structured Concurrency cancelled")

                }

            }
        }

    }
    delay(700)
    println("cancelling parent job")
    parentJob.cancelAndJoin()

    print("MAIN END")


}