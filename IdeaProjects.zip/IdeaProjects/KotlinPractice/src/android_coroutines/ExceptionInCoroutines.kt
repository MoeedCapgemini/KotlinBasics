package android_coroutines

import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main(): Unit = runBlocking {
    val hander = CoroutineExceptionHandler { coroutineContext, exception ->
        println("caught exception:${exception.message}")
    }
    val job = launch(hander) {
        throw RuntimeException("Something went wrong")
    }
    job.join()

}