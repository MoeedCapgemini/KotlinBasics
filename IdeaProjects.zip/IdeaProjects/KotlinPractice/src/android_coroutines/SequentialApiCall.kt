package android_coroutines

import kotlinx.coroutines.*

/*
To call two API calls sequentially in Android using Kotlin Coroutines,
where the second API depends on the first API's response,
you can use suspend functions and CoroutineScope to manage the flow.

In Kotlin, when you use suspend functions inside a coroutine,
they are executed sequentially by default — just like regular code.
*/

/*
fun fetchUserAndPosts() {
    CoroutineScope(Dispatchers.IO).launch {
        try {
            //first api call
            val user = apiService.getUser()
            val posts = apiService.getPosts(user.id)

            withContext(Dispatchers.Main) {
                //Update Ui with Posts
                showPosts(posts)
            }

        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                showError(e.message)
            }

        }
    }
}*/
