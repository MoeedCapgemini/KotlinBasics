package android_coroutines

import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking

fun main():Unit= runBlocking {

    val deferred = async {
        throw IllegalArgumentException("Faild!")

    }
    try {
        deferred.await()

    }catch (e:Exception){
        println("Caught exception from async:${e.message}")
    }

}