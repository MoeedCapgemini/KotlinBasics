package android_coroutines

import kotlinx.coroutines.*
import kotlinx.coroutines.selects.select

fun main(): Unit = runBlocking {
    println("MAIN_START")

        coroutineScope {
            val first = async {
                delay(3000)
                "First Result"
            }

            val second = async {
                delay(1000)
                "Second Result"
            }

            /*val firstResult = select {
                first.onAwait{
                    it
                }

                second.onAwait{
                    it
                }
            }

            println(firstResult)*/
            val result = awaitAll(first,second)


            println(result)
        }



    println("MAIN END")

}

suspend fun secondApiCall(): String {
    delay(1000)
    return "Second Api call Success"
}

suspend fun firstApiCall(): String {
    delay(6000)
    return "First Api Call Success"


}



/*val result1 = first.await()// This will wait ~3 seconds
            val result2 = second.await() // This will return immediately after result1*/