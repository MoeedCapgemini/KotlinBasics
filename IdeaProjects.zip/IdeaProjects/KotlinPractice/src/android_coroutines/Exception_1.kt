package android_coroutines

import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main(): Unit = runBlocking {

    launch {
        try {
            throw RuntimeException("errrorrror")

        }catch (e:Exception){
            println("HANDLED::${e.message}")
        }
    }
}