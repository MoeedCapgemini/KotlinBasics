package android_coroutines

import kotlinx.coroutines.*

fun main(): Unit = runBlocking {

    val handler = CoroutineExceptionHandler { coroutineContext, throwable ->
        println("HANDLED:: ${throwable.message}")
    }


    launch {
        try {
            delay(1000)
            println("CHILD---1")
            throw RuntimeException("ERROR CHILD 1")
        } catch (e: Exception) {
            println("Caught ${e.message}")
        }

    }
    launch {
        delay(1500)
        println("CHILD---2")

    }


}
