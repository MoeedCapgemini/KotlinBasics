package android_coroutines

import kotlinx.coroutines.*

fun main(): Unit = runBlocking {
    println("Main Starts on: ${Thread.currentThread().name}")  //1

    //Independent Coroutines using CoroutineScope
    val job: Job = CoroutineScope(Dispatchers.IO).launch {
        delay(1000)
        println("Independent Coroutine donne on: ${Thread.currentThread().name}")
    }

    coroutineScope {
        launch {
            delay(500)
            println("Structured coroutine done on: ${Thread.currentThread().name}") //3

        }
        println("waiting for stucture coroutine to finish..")//2


    }
    println("MAin ends: ${Thread.currentThread().name}") //4

    job.join()

}