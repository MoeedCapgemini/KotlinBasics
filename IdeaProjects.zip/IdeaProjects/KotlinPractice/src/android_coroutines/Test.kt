package android_coroutines

import kotlinx.coroutines.*

fun main():Unit= runBlocking {
    println("MAIN START")
    CoroutineScope(Dispatchers.IO).launch {
        launch {
            delay(5000)
            println("FIRST")
        }

        launch {
            delay(2000)
            println("SECOND")
        }
    }

    println("MAIN END")

}