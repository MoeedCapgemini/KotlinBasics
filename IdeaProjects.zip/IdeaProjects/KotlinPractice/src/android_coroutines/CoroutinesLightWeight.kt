package android_coroutines

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

fun main() {
    runBlocking {
        launch {
            delay(1000)
            println("First Coroutine")
        }

        launch {
            delay(2000)
            println("Second coroutine")
        }
    }

    println("coroutine completed")
}





