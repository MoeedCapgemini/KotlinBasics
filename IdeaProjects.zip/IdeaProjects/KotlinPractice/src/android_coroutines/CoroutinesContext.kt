package android_coroutines

import kotlinx.coroutines.*
import kotlin.coroutines.CoroutineContext

val customContext:CoroutineContext = Dispatchers.IO + CoroutineName("MyCustomCoroutine")
val customContext1:CoroutineContext = Dispatchers.IO + CoroutineName("Abc")
fun runWithCustomContext() {
    CoroutineScope(customContext).launch {
        println("Running in ${coroutineContext[CoroutineName]}")
    }

}

fun main():Unit= runBlocking {
    runWithCustomContext()
}