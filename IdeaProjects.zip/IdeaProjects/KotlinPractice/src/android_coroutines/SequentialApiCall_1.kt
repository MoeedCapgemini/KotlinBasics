package android_coroutines

import kotlinx.coroutines.*

fun main():Unit = runBlocking {
    println("MAIN START")

    val job = CoroutineScope(Dispatchers.IO).launch {
        val firstApiResult = apiCallOne()
        val secondApiCall = apiCallTwo()

        println("FIRST---$firstApiResult")
        println("SECOND---$secondApiCall")

    }
    job.join()

    println("MAIN END")

}

suspend fun apiCallOne():String{
    delay(5000)
    return "First Api Call"

}

suspend fun apiCallTwo():String{
    delay(2000)
    return "Second Api Call "
}