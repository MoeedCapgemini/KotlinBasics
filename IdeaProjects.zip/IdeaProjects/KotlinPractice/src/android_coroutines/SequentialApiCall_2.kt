package android_coroutines

import kotlinx.coroutines.*

fun main(): Unit = runBlocking {

    val handler = CoroutineExceptionHandler { coroutineContext, throwable ->
        println("HANDLED::${throwable.message}")
    }


    val job = CoroutineScope(Dispatchers.IO + handler).launch {
        supervisorScope {
            val def1 = async { println(getStudent())  }

           val def2 =  async {  println(getStudentActivity()) }

            val result = awaitAll(def1,def2)
            println(result)

        }


    }
    job.join()

}



suspend fun getStudent(): String {
    delay(3000)
    throw RuntimeException("XYXXXXX")

}
suspend fun getStudentActivity(): String {
    delay(2000)
    return "MAKING CHART"

}

data class Student(val name: String, val rollNum: Int)