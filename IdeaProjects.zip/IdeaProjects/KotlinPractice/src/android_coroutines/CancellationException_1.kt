package android_coroutines

import kotlinx.coroutines.*
//Coroutines must check for cancellation explicitly using suspending functions (like delay()) or isActive.
// This is called cooperative cancellation.
//7. How would you cancel a coroutine doing CPU-intensive work?
//Answer:
//Use isActive to check for cancellation manually in a loop.
// 9. What is structured concurrency and how does it relate to cancellation?
//Answer:
//Structured concurrency ensures that child coroutines are tied to the lifecycle of their parent.
// Cancelling a parent coroutine cancels all its children.

fun main():Unit= runBlocking {

    val job = launch {
        try {
            println("Task started")
            delay(5000)
            println("Task Completed")

        }catch (e:CancellationException){
            println("Task was cancelled")
        }
    }
    delay(2000)
    println("Cancelling Task")
    job.cancelAndJoin()
    println("Main Program ends")

}