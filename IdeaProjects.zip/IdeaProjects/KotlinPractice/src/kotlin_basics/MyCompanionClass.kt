package kotlin_basics
//🔐 What is Thread Safety?
//Thread safety means that a piece of code or data structure can be safely used by multiple
// threads at the same time without causing unexpected behavior or data corruption

object A{

}


class MyCompanionClass {
    companion object {
        const val CONSTANT_VALUE = 42

        fun create():MyCompanionClass {
            println("creating an instance of MyCompanionClass")
            return MyCompanionClass()
        }



    }



    fun greet() {
        println("Hello from MyCompanionClass instance")
    }
}

fun main() {
    val instance = MyCompanionClass.create()
    MyCompanionClass.create()
    MyCompanionClass.create()
    instance.greet()


}

