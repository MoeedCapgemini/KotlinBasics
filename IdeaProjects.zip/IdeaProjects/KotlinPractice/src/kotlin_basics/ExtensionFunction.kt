package kotlin_basics

fun String.toSmallChar():String{
    return this.lowercase()
}

fun String.reverseWords():String{
    return this.split(" ").reversed().joinToString(" ")
}

fun String.removeSpaces():String{
    return this.replace(" ","")
}

fun main() {
    val string = "ABDUL MOEED".removeSpaces()
    println(string)
}