package kotlin_basics

import kotlin_basics.MySealedClass.Error
import kotlin_basics.MySealedClass.Success


sealed class MySealedClass(val string:String) {
    data class Success(val msg: String) : MySealedClass(msg)
    data class Error(val errorMsg: String) : MySealedClass(errorMsg)


}
fun handleResult(mySealedClass: MySealedClass) {
    when (mySealedClass) {
        is Success -> println(mySealedClass.msg)
        is Error -> println("ERROR")

    }
}

fun main() {
    val sealedStatus = MySealedClass.Success("Sucesssjjjjjjjjjjjj")
    handleResult(sealedStatus)

}