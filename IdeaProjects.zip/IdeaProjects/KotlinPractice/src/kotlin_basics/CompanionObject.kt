package kotlin_basics


class MyClass {
    companion object {
        fun callObject() {
            println(MyObject.myObject())
        }
    }

}

object MyObject {

    fun myObject(): String {
        return "I am from Object Class"
    }
}

fun main() {
    MyClass.callObject()

}