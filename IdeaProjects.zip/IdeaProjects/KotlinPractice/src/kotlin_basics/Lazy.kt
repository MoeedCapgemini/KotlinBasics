package kotlin_basics

fun main() {
    println("Program started")
    val greeting:String by lazy {
        println("initialising lazy..")
        "Hello"
    }

    println("before accessing..")
    println(greeting)
    println(greeting)
}