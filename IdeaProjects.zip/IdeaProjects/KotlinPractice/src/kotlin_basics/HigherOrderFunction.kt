package kotlin_basics






fun operateOnNumbers(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
    return operation(a, b)
}


fun add(a: Int, b: Int, fn: (Int, Int) -> Int): Int {
    return fn(a, b)
}

fun sum(a: Int, b: Int): Int {
    return a + b
}

fun main() {

    val sum1 = operateOnNumbers(5, 4) { x, y -> x + y }
    val product = operateOnNumbers(6, 7) { x, y -> x * y }

    val result = add(4, 5, ::sum)
    println(product)
}

