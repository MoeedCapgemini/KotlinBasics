package S_O_L_I_D

//A class should have only one reason to change,meaning it should have only one responsibility

//BAD-Violates SRP
class UserManager {
    fun loginUser(){
        //logic to login
    }

    fun saveUserData(){
    }

    fun sendWelcomeEmail(){
    }
}


//GOOD FOLLOWS SRP
class AuthUser(){
    fun loginUser(){}
}

class UserRepository(){
    fun saveUserData(){

    }
}
class EmailService{
    fun sendWelcomeEmail(){

    }
}