package S_O_L_I_D

//Client should not force to implement interfaces they do not use

//Violates ISP
interface Worker {
    fun eat()
    fun work()
}

class Robot : Worker {
    override fun eat() {
        println("Robot doesn't eat")
    }

    override fun work() {
        println("Robot is working")
    }
}

interface Eatable {
    fun eat()
}

interface Workable {
    fun work()
}

class Human : Eatable, Workable {
    override fun eat() {
        println("Human is taking food")
    }

    override fun work() {
        println("Human doing work")
    }

}

class Robots : Workable {
    override fun work() {
        println("Robots doing work..")
    }

}