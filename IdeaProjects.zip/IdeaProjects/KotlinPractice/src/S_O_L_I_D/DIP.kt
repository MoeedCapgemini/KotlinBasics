package S_O_L_I_D

//High level modules should not depend on low level modules .Both should depend on abstractions(interfaces).
//Abstraction should not depend on details.Details should depend on abstractions

//Without DIP
// Tight Coupling

class SendNotificationMessenger{
    private val emailService = EmailService()

    fun sendNotificationMessages(){
        emailService.sendWelcomeEmail()
    }
}

interface MessageService{
    fun sendMessage(message:String)
}

//Low Level
class EmailTyypeService:MessageService{
    override fun sendMessage(message: String) {
        println("Sending email $message")
    }
}

class NotificationOfTypeSender(private val service: MessageService){
    fun notifyUser(){
        service.sendMessage("Hello from DIP")
    }

}


fun main() {
    val service:MessageService = EmailTyypeService()
    val sender = NotificationOfTypeSender(service)
    sender.notifyUser()
}