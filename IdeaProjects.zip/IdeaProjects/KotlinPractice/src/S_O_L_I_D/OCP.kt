package S_O_L_I_D
//Open Closed Principle
//Classes should be open for extension but closed for modification.


class SendNotification {
    fun send(type: String) {
        if (type == "email") {
            //send email
        } else if (type == "sms") {
            //send sms
        }
    }
}

interface NotificationSender {
    fun send()
}

class SendEmail : NotificationSender {
    override fun send() {
        TODO("Not yet implemented")
    }

}

class SendSMS : NotificationSender {
    override fun send() {
        println("Send SMS")
    }

}

fun fireNotification(notification: NotificationSender) {
    notification.send()
}

fun main() {
    val sender:NotificationSender = SendSMS()
    fireNotification(sender)
}


