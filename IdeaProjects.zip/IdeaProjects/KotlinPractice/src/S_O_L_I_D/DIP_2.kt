package S_O_L_I_D

class SendingNotification {
    val emailService = EmailService()
    fun sendNotification() {
        emailService.sendWelcomeEmail()
    }

}

interface NotificationSending {
    fun send(msg: String)
}

class EmailByMessageSend : NotificationSending {
    override fun send(msg: String) {
        println("Sending by email $msg")
    }
}

class SendingByTextMessage(val notificationSending: NotificationSending) {
    fun notifYMe() {
        notificationSending.send("Hello from DIP")
    }
}

fun main() {
    val notificationSending: NotificationSending = EmailByMessageSend()
    val senderss = SendingByTextMessage(notificationSending)
    senderss.notifYMe()
}