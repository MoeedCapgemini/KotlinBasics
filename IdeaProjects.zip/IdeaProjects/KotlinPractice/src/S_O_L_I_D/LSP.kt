package S_O_L_I_D

//Subtype must be substitutable with their base type without breaking their behaviour

//BAD
open class Bird {
    open fun fly() {
        println("Birds flying..")
    }
}

class Ostrich : Bird() {
    override fun fly() {
        throw UnsupportedOperationException("Ostrich can't fly")
    }
}

interface Birdd

interface FlyingBird:Birdd{
    fun fly()
}

class Sparrow : FlyingBird{
    override fun fly() {
        println("Sparrow flying...")
    }
}

class Ostrichh :Birdd{
    fun walk(){
        println("Ostrich walking..")
    }
}



