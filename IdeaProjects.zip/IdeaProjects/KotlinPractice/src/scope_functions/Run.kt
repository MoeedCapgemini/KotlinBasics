package scope_functions


//run takes object as a context and then return the value as a Lambda Expression
//If you need to modify the original object and get the modified object itself as the result,run is a better choice

//last expression will be the return value
fun main() {

    val numbers = mutableListOf(1,2,3,4,5,6)
    numbers.run {
        removeAll{
            it%2 ==0
        }
        this
    }
    println(numbers)
    /*val str = "Hello Moeed!"
    val result = str.run {
        length
    }
    println(result)*/
}