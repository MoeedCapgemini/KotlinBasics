package scope_functions


//also: The context object is accessed as it, and it returns the object itself.
// It's useful for performing side effects, such as logging or debugging.
data class EmplAlso(var name:String="",var age:Int=10)

fun main() {
    val numbers = mutableListOf(1,2,3)
    numbers.also {
        println("Before adding $it")
    }.add(4)

    println(numbers)
}