package scope_functions

data class Emppp(var name:String="",var age:Int=18)

fun main() {
    val emppp = Emppp()

    emppp.let {
        it.age=19
        it.name="moeed"


    }

    emppp.run {
        age = 10
        name = "AbdulRun"


    }

    with(emppp){
        age = 18
        name="Moeed Run"

    }

    println(emppp)

}