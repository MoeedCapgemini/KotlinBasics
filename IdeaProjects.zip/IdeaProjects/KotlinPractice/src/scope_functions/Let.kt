package scope_functions

///Let takes object as an argument and return the value of the lambda expression
//If want to perform some operation on it and get a new value,let is a good choice

//it returns last value of expression

fun main() {
    val str: String = "Hello, World!"
    val result = str.let {
        it.length *2
    }
    println(result)
}

