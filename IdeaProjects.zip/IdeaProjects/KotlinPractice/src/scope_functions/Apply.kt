package scope_functions


//apply always return as a object,return type will be object always

data class Employi(var name: String = "", var age: Int = 10)

fun main() {
    val employi = Employi()
    employi.age = 19
    employi.name = "seam"

   val result= employi.apply {
        age = 32
        name = "Rohanllllllllllauuuuu"

    }

    println(result)
}