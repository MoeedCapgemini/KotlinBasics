package scope_functions

//With also returns the last value of the expression

data class Teacher(var name:String="",var age:Int=12)

fun main() {
    val teacher = Teacher()
    val result =with(teacher) {
        name = "Abdul MOEEED"
        age = 82
    }
    println(teacher)
}