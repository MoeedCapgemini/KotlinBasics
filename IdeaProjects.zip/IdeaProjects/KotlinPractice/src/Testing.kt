fun main() {
    var str = "hello"
    val caps = str.takeIf{it.isNotEmpty()}?.uppercase()
    println(caps)
}