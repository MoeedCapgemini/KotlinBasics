package question_20

fun removeDuplicates(input:List<Int>):List<Int>{
    val seen = mutableSetOf<Int>()
    val result = mutableListOf<Int>()
    for (item in input){
        if (item !in result){
            //.add(item) //1 2
            result.add(item) //1 2
        }
    }
    return result
}

fun removeDuplicatesChars(string:String):String{
    val result = StringBuilder()
    for (ch in string){
        if (ch !in result){

            result.append(ch) //1 2
        }
    }
    return result.toString()
}

fun main() {
    val input = "programming mdddmslml"
   // val list = listOf(0,0,0,1,2,2,0,0,3,4,4,5,0,0)
   // val uniqueList = removeDuplicates(list)
   // println(uniqueList)

    val output = removeDuplicatesChars(input)
    println(output)
}