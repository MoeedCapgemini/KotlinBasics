package question_20


//Kotlin scope functions are higher order function that allow executing a block of
// code within the context of an object

//let executes a block of code and returns the result of the lambda expression
// The context object is accessed using it

//with: A non-extension function that takes the object as an argument and executes a block of code.
// The context object is accessed using this

//apply: Executes a block of code and returns the object itself.
// It's commonly used for object configuration and initialization.
// The context object is accessed using this.


//data class Person(var name:String,var age:Int)


fun main() {
    val message: String? = "hello"
   message?.let {
       val upperCase = it.uppercase()
       println(upperCase)
   }

    message?.run {
        val lowerCase = this.lowercase()
        print(lowerCase)

    }

}

//Kotlin scope functions are higher-order functions that allow executing a block of code within the context of an object. They provide a concise way to manipulate objects and improve code readability. The five scope functions in Kotlin are let, run, with, apply, and also.
//Scope Functions and Their Usage
//let: Executes a block of code and returns the result of the lambda expression. It is often used for null safety checks or transformations. The context object is accessed using it.
//Kotlin
//
//    val name: String? = "Kotlin"
//    val length = name?.let {
//        it.length
//    }
//    println(length) // Output: 6
//run: Similar to let, but the context object is accessed using this. It's useful when you want to call multiple methods on the same object.
//Kotlin
//
//    val person = Person("Alice", 30)
//    val description = person.run {
//        "Name: $name, Age: $age"
//    }
//    println(description) // Output: Name: Alice, Age: 30
//with: A non-extension function that takes the object as an argument and executes a block of code. The context object is accessed using this. It is suitable when you want to perform multiple operations on an object without repeatedly referencing it.
//Kotlin
//
//    val person = Person("Bob", 25)
//    val updatedPerson = with(person) {
//        age = 26
//        "Updated age: $age"
//    }
//     println(updatedPerson) // Output: Updated age: 26
//apply: Executes a block of code and returns the object itself. It's commonly used for object configuration and initialization. The context object is accessed using this.
//Kotlin
//
//    val person = Person("Charlie", 35).apply {
//        city = "New York"
//    }
//    println(person) // Output: Person(name=Charlie, age=35, city=New York)
//also: Executes a block of code and returns the object itself. It is useful for performing side effects or additional operations without modifying the object. The context object is accessed using it.
//Kotlin
//
//    val numbers = mutableListOf(1, 2, 3)
//    numbers.also {
//        it.add(4)
//    }.also {
//        println("List size: ${it.size}") // Output: List size: 4
//    }
//    println(numbers) // Output: [1, 2, 3, 4]
//Difference between let and run
//The main difference between let and run lies in how they reference the context object. let uses it to refer to the object, while run uses this. Additionally, let is often used for null safety and transformations, whereas run is suitable for calling multiple methods on the same object.
//Kotlin
//
//data class Person(var name: String, var age: Int, var city: String? = null)
//Kotlin
//
//val message: String? = "Hello"
//
//// Using let
//message?.let {
//    val upperCaseMessage = it.toUpperCase()
//    println(upperCaseMessage) // Output: HELLO
//}
//
//// Using run
//message?.run {
//    val lowerCaseMessage = this.toLowerCase()
//    println(lowerCaseMessage) // Output: hello
//}
//In the example above, let and run achieve similar results, but their context object references differ. let uses it to access the message, while run uses this. The choice between them depends on personal preference and code context.