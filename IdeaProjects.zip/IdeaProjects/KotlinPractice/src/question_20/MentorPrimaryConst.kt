package question_20

class MentorPrimaryConst(firstName: String, lastName: String) {

    init {

        //The init block gets immediately called after the primary constructor but before the secondary constructor
        val fullName = "$firstName $lastName"
        println(fullName)
    }

    constructor(firstName: String, lastName: String, interest: String) : this(firstName, lastName) {
        //the primary constructor can't contain any code, but  we can write code in secondary constructor


    }
}