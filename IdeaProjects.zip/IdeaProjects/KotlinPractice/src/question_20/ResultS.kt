package question_20

sealed class ResultS {
    class Success(val msg: String) : ResultS()
    class Error(val errorMsg: String) : ResultS()
    data object Loading : ResultS()
}

fun processResult(result: ResultS) {
    when (result) {
        is ResultS.Error -> println("Result is ${result.errorMsg}")
        ResultS.Loading -> println("Loading...")
        is ResultS.Success -> println("Result is ${result.msg}")
    }
}

fun main() {
    val result = ResultS.Success("Successfull")
    processResult(result)

}
