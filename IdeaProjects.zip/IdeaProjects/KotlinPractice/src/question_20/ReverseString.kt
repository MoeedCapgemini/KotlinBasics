package question_20

fun reverseString(inputString: String): String {
    val chars = inputString.toCharArray()
    var start = 0
    var end = chars.size - 1
    while (start < end) {
        val temp = chars[start]
        chars[start] = chars[end]
        chars[end] = temp
        start++
        end--

    }
    return String(chars)
}


fun reverseEachWordManual(input:String):String{
    val result = StringBuilder()
    val word = StringBuilder()
    for (char in input){
        if (char!=' '){
            word.append(char)
        }else
        {
            for (i in word.length-1 downTo 0){
                result.append(word[i])
            }
            result.append(' ')
            word.setLength(0)
        }
    }
    for (i in word.length-1 downTo 0){
        result.append(word[i])
    }

    return result.toString()
}

fun main() {
   /* val sentence = "Hello World From Kotlin"
    println(reverseEachWordManual(sentence))*/


    val inputString = "1234566"
    ///val inputString = "Abdul Moeed Android Developer"
    val reversString = reverseString(inputString)
    println(reversString)

}